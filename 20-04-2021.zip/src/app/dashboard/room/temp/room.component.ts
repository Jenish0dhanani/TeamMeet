//@ts-nocheck
import { Component, ElementRef, OnInit, Renderer2, ViewChild, HostListener } from "@angular/core";
import { Router } from "@angular/router";
import * as io from 'socket.io-client'
import { UserdataService } from "src/service/userdata.service";
import { MatSnackBar } from '@angular/material/snack-bar';
import { DatePipe } from '@angular/common'

@Component({
  selector: 'app-room',
  templateUrl: 'room.component.html',
  styleUrls: ['room.component.css']
})
export class RoomComponent implements OnInit {
  @ViewChild('remoteVideo') remoteVideoComponent: ElementRef | any;
  @ViewChild('roominput') roominput: ElementRef | any;
  @ViewChild('roomSelectionContainer') roomSelectionContainer: ElementRef | any;
  @ViewChild('video_chat_container') videoChatContainer: ElementRef | any;
  @ViewChild('local_video') localVideoComponent: ElementRef | any;
  @ViewChild('btn_ctrl') btnCtrl: ElementRef | any;
  private localStream = new MediaStream;
  private remoteStream = new MediaStream;
  private screenShareStream = new MediaStream;
  rtcPeerConnection: any
  isRoomCreator: any;
  roomId: any;
  serverConnection: any;
  localUuid: any;
  peerConnections = {};
  localDisplayName: any;
  WS_PORT = 8443;
  url: string = 'https://192.168.43.119:5000'
  // url:string='https://localhost:5000'
  socket = io(this.url)
  mediaConstrain = {
    video: { width: { max: 1920, ideal: 1280, min: 1024 }, height: { max: 1080, ideal: 720, min: 576 }, facingMode: { exact: "user" } },
    audio: { echoCancellation: true, noiseSuppression: true }
  }
  iceServers = {
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
      { urls: 'stun:stun2.l.google.com:19302' },
      { urls: 'stun:stun3.l.google.com:19302' },
      { urls: 'stun:stun4.l.google.com:19302' },
    ],
  }


  constructor(private renderer: Renderer2, private userdata: UserdataService, private router: Router, private snack: MatSnackBar, private datePipe: DatePipe) {
    console.log(this.socket)
  }


  async ngOnInit() {
    this.peerConnections = {};
   }

  async ngAfterViewInit() {
    const joinRoom = () =>{
      this.localUuid = createUUID()
      function createUUID() {
        function s4() {
          return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
        }
      
        return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
      }

      var urlParams = new URLSearchParams(window.location.search);
      this.localDisplayName = urlParams.get('displayName') || prompt('Enter your name', '');
      document.getElementById('localVideoContainer').appendChild(makeLabel(this.localDisplayName));
  
      // this.localUuid = sessionStorage.getItem('uid')
  
  
      // msgcontainer?.style.display = 'block';
  
      if (navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices.getUserMedia(this.mediaConstrain)
      .then(stream => {
        this.localStream = stream;
        document.getElementById('localVideo').srcObject = stream;
      }).catch(errorHandler)

      // set up websocket and message all existing clients
      .then(() => {
        this.serverConnection = new WebSocket('wss://192.168.43.119:' + this.WS_PORT);
        
        this.serverConnection.onmessage = gotMessageFromServer;
        console.log(this.serverConnection.onmessage)
        this.serverConnection.onopen = event => {
          this.serverConnection.send(JSON.stringify({ 'displayName': this.localDisplayName, 'uuid': this.localUuid, 'dest': 'all' }));
        }
      }).catch(errorHandler);
  
      } else {
        alert('Your browser does not support getUserMedia API');
      }
    }

    joinRoom()

    function makeLabel(label) {
      var vidLabel = document.createElement('div');
      vidLabel.appendChild(document.createTextNode(label));
      vidLabel.setAttribute('class', 'videoLabel');
      return vidLabel;
    }

    const gotMessageFromServer = (message) =>{
      console.log(message)
      var signal = JSON.parse(message.data);
      var peerUuid = signal.uuid;
  
      // Ignore messages that are not for us or from ourselves
      if (peerUuid == this.localUuid || (signal.dest != this.localUuid && signal.dest != 'all')) return;
  
      if (signal.displayName && signal.dest == 'all') {
        // set up peer connection object for a newcomer peer
        
        setUpPeer(peerUuid, signal.displayName);
  
        this.serverConnection.send(JSON.stringify({ 'displayName': this.localDisplayName, 'uuid': this.localUuid, 'dest': peerUuid }));
  
      } else if (signal.displayName && signal.dest == this.localUuid) {
        // initiate call if we are the newcomer peer
        setUpPeer(peerUuid, signal.displayName, true);
       
  
      } else if (signal.sdp) {
        this.peerConnections[peerUuid].pc.setRemoteDescription(new RTCSessionDescription(signal.sdp)).then(() => {
          // Only create answers in response to offers
          if (signal.sdp.type == 'offer') {
            this.peerConnections[peerUuid].pc.createAnswer().then(description => createdDescription(description, peerUuid)).catch(errorHandler);
          }
        }).catch(this.errorHandler);
  
      } else if (signal.ice) {
        this.peerConnections[peerUuid].pc.addIceCandidate(new RTCIceCandidate(signal.ice)).catch(errorHandler);
      }
    }

    function errorHandler(error) {
      console.log(error);
    }
  
    const setUpPeer = (peerUuid, displayName, initCall = false)=> {
      this.peerConnections[peerUuid] = { 'displayName': displayName, 'pc': new RTCPeerConnection(this.iceServers) };
      this.peerConnections[peerUuid].pc.onicecandidate = event => gotIceCandidate(event, peerUuid);
      this.peerConnections[peerUuid].pc.ontrack = event => gotRemoteStream(event, peerUuid);
      this.peerConnections[peerUuid].pc.oniceconnectionstatechange = event => checkPeerDisconnect(event, peerUuid);
      this.peerConnections[peerUuid].pc.addStream(this.localStream);
    
      if (initCall) {
        this.peerConnections[peerUuid].pc.createOffer().then(description => createdDescription(description, peerUuid)).catch(errorHandler);
      }
    }

    const gotIceCandidate = (event, peerUuid) => {
      if (event.candidate != null) {
        this.serverConnection.send(JSON.stringify({ 'ice': event.candidate, 'uuid': this.localUuid, 'dest': peerUuid }));
      }
    }
  
    const createdDescription = (description, peerUuid) => {
      console.log(`got description, peer ${peerUuid}`);
      this.peerConnections[peerUuid].pc.setLocalDescription(description).then(() => {
        this.serverConnection.send(JSON.stringify({ 'sdp': this.peerConnections[peerUuid].pc.localDescription, 'uuid': this.localUuid, 'dest': peerUuid }));
      }).catch(errorHandler);
    }
  
    const gotRemoteStream = (event, peerUuid) => {
      console.log(`got remote stream, peer ${peerUuid}`);
      //assign stream to new HTML video element
      var vidElement = document.createElement('video');
      vidElement.setAttribute('autoplay', '');
      vidElement.setAttribute('muted', '');
      vidElement.srcObject = event.streams[0];
  
      var vidContainer = document.createElement('div');
      vidContainer.setAttribute('id', 'remoteVideo_' + peerUuid);
      vidContainer.setAttribute('class', 'videoContainer');
      vidContainer.appendChild(vidElement);
      vidContainer.appendChild(makeLabel(this.peerConnections[peerUuid].displayName));
  
      document.getElementById('videos').appendChild(vidContainer);
  
     updateLayout();
    }
    // jo mobile ma kholyu connect no thyu
    const checkPeerDisconnect = (event, peerUuid) => {
      var state = this.peerConnections[peerUuid].pc.iceConnectionState;
      console.log(`connection with peer ${peerUuid} ${state}`);
      if (state === "failed" || state === "closed" || state === "disconnected") {
        delete this.peerConnections[peerUuid];
        document.getElementById('videos').removeChild(document.getElementById('remoteVideo_' + peerUuid));
        updateLayout();
      }
    }
  
    const updateLayout = () => {
      // update CSS grid based on number of diplayed videos
      var rowHeight = '98vh';
      var colWidth = '98vw';
  
      var numVideos = Object.keys(this.peerConnections).length + 1; // add one to include local video
  
      if (numVideos > 1 && numVideos <= 4) { // 2x2 grid
        rowHeight = '48vh';
        colWidth = '48vw';
      } else if (numVideos > 4) { // 3x3 grid
        rowHeight = '32vh';
        colWidth = '32vw';
      }
  
      document.documentElement.style.setProperty(`--rowHeight`, rowHeight);
      document.documentElement.style.setProperty(`--colWidth`, colWidth);
    }

  }

  const room= ()=>{
      }
  
}
