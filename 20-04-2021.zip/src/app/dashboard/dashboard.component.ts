import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AuthService } from 'src/service/auth.service';
import { UserdataService } from 'src/service/userdata.service';
import { UserProfileComponent } from './user-profile/user-profile.component'

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit { 
  uid="";
  unbounded = false;
  user={"id":"","fname":'',"lname":'','mobile':"",'email':"",'pass':""};
  isLoggedIn:boolean=false;
  constructor(private router:Router,private authService:AuthService,public dialog: MatDialog, private userdata:UserdataService) { 
    
  }
  checkRoom(){
    if(location.pathname=='/dashboard/room'){
      return false
    }
    return true
  }

  async ngOnInit(): Promise<void> {
    this.uid="";
    await this.dashboard();
    this.userdata.uid = this.uid;
  }
  isRoom(){
    if(location.pathname=='/dashboard/room'){return false}
    return true
  }

  dashboard(){
    this.authService.verify().subscribe(
      (data)=> {
        if(data){
          // console.log(data);
          // console.log("Response Receiverd"+JSON.stringify(data))
          this.uid=JSON.stringify(data.user.id);
          this.userdata.uid = this.uid
          
          this.authService.getUser(this.uid).subscribe(
            (data)=>{
              if(data){
                this.user=data;
                // console.log(this.user)
                this.userdata.userDetails=this.user
              }
              else{
                console.error("exception no response from api");
              }
            },
            error=>{console.error("exception"+JSON.stringify(error))}
          );
        }
      },
      error => {console.log("Exception"+JSON.stringify(error.error));
    });
  }
  
  openDialog(): void {
    const dialogRef = this.dialog.open(UserProfileComponent,{
      width: '550px',
      // maxHeight: '90vh'
      height:'auto'
    });

    dialogRef.afterClosed().subscribe(result => {
      this.ngOnInit();
    });
  }

  get userid(){
    return this.uid
  }

  LogOut(){
    // location.reload()
    localStorage.removeItem('token');
    sessionStorage.removeItem('uid');
    this.uid="";
    this.user={"id":"","fname":'',"lname":'','mobile':"",'email':"",'pass':""};
    this.router.navigate(['login']); 
  }
}
