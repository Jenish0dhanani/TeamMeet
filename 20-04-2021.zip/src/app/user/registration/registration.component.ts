import { Component,OnInit, ViewChild} from '@angular/core';
import {FormBuilder,FormGroup,FormGroupDirective,Validators} from '@angular/forms';
import { UsernameValidator, passvalidator } from 'src/app/validators';
import { MyErrorStateMatcher } from 'src/app/myerrorstatematcher';
import { AuthService } from 'src/service/auth.service';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})

export class RegistrationComponent {
  form: FormGroup;
  matcher= new MyErrorStateMatcher();
  msg="";
  @ViewChild(FormGroupDirective) formGroupDirective: FormGroupDirective | undefined;
  constructor(private fb: FormBuilder, private authService:AuthService,private _snackBar: MatSnackBar) {
    this.form = this.fb.group({
      lnamectrl: ['', 
        [Validators.required,
        Validators.pattern('^[a-zA-Z \-\']+'),
        Validators.maxLength(15),
        UsernameValidator.cannotContainSpace
      ],
      ],
      fnamectrl: ['',
        [Validators.required,
        Validators.pattern('^[a-zA-Z \-\']+'),
        Validators.maxLength(15),
        UsernameValidator.cannotContainSpace]
      ],
      emailctrl: ['',
        [Validators.required,
        Validators.email]
      ],
      mobileno: ['',
        [Validators.required,
        Validators.pattern('^[6-9][0-9]{9}$')]
      ],
      password: ['',
          [Validators.required,]
      ],
      
      confirmpassword: ['',
          [Validators.required, passvalidator]
      ],
      
    });
}

  ngOnInit(): void{}
  get lnamectrl(): any {
    return this.form.get('lnamectrl')
  }

  get fnamectrl(): any {
    return this.form.get('fnamectrl');
  }

  get emailctrl(): any {
    return this.form.get('emailctrl');
  }

  get password(): any {
    return this.form.get('password');
  }

  get mobileno(): any{
    return this.form.get('mobileno');
  }

  get confirmpassword(): any {
    return this.form.get('confirmpassword');
  }

  
  horizontalPosition: MatSnackBarHorizontalPosition = 'right';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  durationInSeconds = 5;

  openSnackBar(message: string, action: string, className: string) {

    this._snackBar.open(message, action, {
     duration: 5000,
     verticalPosition: 'top',
     horizontalPosition: 'right',
     panelClass: [className],
   });
}

  fname:any = "";
  lname:any = "";
  email:any="";
  hide = true;
  hide1 = true;

  user = {fname:"",lname:"",mobile:"",email:"",pass:""};

  onRegister(f: FormGroup): void {
    if(f.valid){
      console.log(f.value)
     this.user={fname:f.value.fnamectrl,lname:f.value.lnamectrl,mobile:f.value.mobileno,email:f.value.emailctrl,pass:f.value.password}

    // this.authService.login(f.value.emailctrl,f.value.password)
    this.authService.register(this.user).subscribe(
      data=> {
        console.log("Response Receiverd"+JSON.stringify(data))
        this.msg= JSON.stringify(data);
        this.openSnackBar(JSON.stringify(data),'Close','blue-snackbar');
        // this.form.reset();
        // this.form.clearValidators
        setTimeout(() => 
        this.formGroupDirective?.resetForm(), 0)
        console.log(this.msg);
      },
      error => {console.log("Exception"+JSON.stringify(error.error));
      this.msg= JSON.stringify(error.error);
      
      this.form.setErrors({'Invalid':true});
      this.form.reset()
      
      this.openSnackBar(error.error,'Close','red-snackbar');
      console.log(this.form);
      console.log(this.msg);  
    }
    )
    }
   
  }
  
}
