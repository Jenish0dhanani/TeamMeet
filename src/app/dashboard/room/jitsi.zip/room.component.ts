//@ts-nocheck
import { Component, ElementRef, OnInit, ViewChild, HostListener } from "@angular/core";
import 'src/assets/js/external_api.js'
import { Router } from '@angular/router';

declare var JitsiMeetExternalAPI: any;

@Component({
    selector: 'app-room',
    templateUrl: 'room.component.html',
    styleUrls: ['room.component.css']
})
export class RoomComponent implements OnInit  {
  
  title = 'sidenav';
  domain: string = "localhost:8443";
  options: any;
  api: any;

  constructor(private router:Router) { }

  async ngOnInit() {}

  async ngAfterViewInit(){
    this.options = {
      roomName: "123",
      // jwt:localStorage.getItem('token'),
      configOverwrite: { startWithAudioMuted: true, startWithVideoMuted: true },
      height: 700,
      parentNode: document.querySelector('#meet'),
      userInfo:{
        displayName:sessionStorage.getItem('uid')
      },
      interfaceConfigOverwrite: {  },
    }

    this.api = new JitsiMeetExternalAPI(this.domain, this.options)
    
    api.executeCommand('hangup')
    // elmnt.style.display = "none";
  }

  executeCommand(command: string) {
    this.api.executeCommand(command);;
    if(command == 'hangup') {
        this.router.navigate(['/dashboard']);
        return;
    }

    if(command == 'toggleAudio') {
        this.isAudioMuted = !this.isAudioMuted;
    }

    if(command == 'toggleVideo') {
        this.isVideoMuted = !this.isVideoMuted;
    }
}

}


